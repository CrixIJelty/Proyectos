package com.example.app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AgregarJuegoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_agregar_juego);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top,
                    systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText etNombreJuego = findViewById(R.id.etNombreJuego);
        EditText etGenero = findViewById(R.id.etGenero);
        EditText etPlataforma = findViewById(R.id.etPlataforma);
        EditText etAnio = findViewById(R.id.etAnio);
        EditText etDesarrollador = findViewById(R.id.etDesarrollador);

        RadioGroup rgEstado = findViewById(R.id.rgEstado);

        Button btnGuardar = findViewById(R.id.btnGuardar);

        btnGuardar.setOnClickListener(v -> {

            String nombre = etNombreJuego.getText().toString().trim();
            String genero = etGenero.getText().toString().trim();
            String plataforma = etPlataforma.getText().toString().trim();
            String anio = etAnio.getText().toString().trim();
            String desarrollador = etDesarrollador.getText().toString().trim();

            if (nombre.isEmpty() ||
                    genero.isEmpty() ||
                    plataforma.isEmpty() ||
                    anio.isEmpty() ||
                    desarrollador.isEmpty()) {

                Toast.makeText(this,
                        "Complete todos los campos",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            String estado;

            if (rgEstado.getCheckedRadioButtonId() == R.id.rbJugando) {
                estado = "Jugando";
            } else if (rgEstado.getCheckedRadioButtonId() == R.id.rbCompletado) {
                estado = "Completado";
            } else {
                estado = "Pendiente";
            }


            Juego nuevoJuego = new Juego(
                    nombre,
                    genero,
                    plataforma,
                    Integer.parseInt(anio),
                    desarrollador,
                    estado
            );

// Guardar en el repositorio

            RepositorioJuegos.listaJuegos.add(nuevoJuego);

            Toast.makeText(this,
                    "Videojuego registrado correctamente",
                    Toast.LENGTH_LONG).show();

            finish();
        });
    }
}
