package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetalleJuegoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_detalle_juego);

        TextView tvNombre = findViewById(R.id.tvNombre);
        TextView tvGenero = findViewById(R.id.tvGenero);
        TextView tvPlataforma = findViewById(R.id.tvPlataforma);
        TextView tvAnio = findViewById(R.id.tvAnio);
        TextView tvDesarrollador = findViewById(R.id.tvDesarrollador);
        TextView tvEstado = findViewById(R.id.tvEstado);

        Button btnRegresar = findViewById(R.id.btnRegresar);
        Button btnEditar = findViewById(R.id.btnEditar);

        String nombre = getIntent().getStringExtra("nombre");
        String genero = getIntent().getStringExtra("genero");
        String plataforma = getIntent().getStringExtra("plataforma");
        int anio = getIntent().getIntExtra("anio", 0);
        String desarrollador = getIntent().getStringExtra("desarrollador");
        String estado = getIntent().getStringExtra("estado");

        int posicion = getIntent().getIntExtra("posicion", -1);

        tvNombre.setText("Nombre: " + nombre);
        tvGenero.setText("Género: " + genero);
        tvPlataforma.setText("Plataforma: " + plataforma);
        tvAnio.setText("Año: " + anio);
        tvDesarrollador.setText("Desarrollador: " + desarrollador);
        tvEstado.setText("Estado: " + estado);

        btnRegresar.setOnClickListener(v -> finish());

        btnEditar.setOnClickListener(v -> {

            Intent intent = new Intent(
                    DetalleJuegoActivity.this,
                    EditarJuegoActivity.class
            );

            intent.putExtra("posicion", posicion);

            startActivity(intent);
        });
    }
}