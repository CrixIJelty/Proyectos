package com.example.app;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class EditarJuegoActivity extends AppCompatActivity {

    Spinner spinnerJuegos;

    EditText etNombre;
    EditText etGenero;
    EditText etPlataforma;
    EditText etAnio;
    EditText etDesarrollador;

    RadioGroup rgEstado;

    Button btnGuardarCambios;

    ArrayList<String> nombresJuegos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_editar_juego);

        spinnerJuegos = findViewById(R.id.spinnerJuegos);

        etNombre = findViewById(R.id.etEditarNombre);
        etGenero = findViewById(R.id.etEditarGenero);
        etPlataforma = findViewById(R.id.etEditarPlataforma);
        etAnio = findViewById(R.id.etEditarAnio);
        etDesarrollador = findViewById(R.id.etEditarDesarrollador);

        rgEstado = findViewById(R.id.rgEditarEstado);

        btnGuardarCambios = findViewById(R.id.btnGuardarCambios);

        nombresJuegos = new ArrayList<>();

        for (Juego juego : RepositorioJuegos.listaJuegos) {
            nombresJuegos.add(juego.getNombre());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                nombresJuegos
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerJuegos.setAdapter(adapter);

        int posicionRecibida = getIntent().getIntExtra("posicion", -1);

        if (posicionRecibida >= 0 && posicionRecibida < nombresJuegos.size()) {
            spinnerJuegos.setSelection(posicionRecibida);
        }

        spinnerJuegos.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        cargarDatosJuego(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                }
        );

        btnGuardarCambios.setOnClickListener(v -> guardarCambios());
    }

    private void cargarDatosJuego(int position) {

        if (RepositorioJuegos.listaJuegos.isEmpty()) {
            return;
        }

        Juego juego = RepositorioJuegos.listaJuegos.get(position);

        etNombre.setText(juego.getNombre());
        etGenero.setText(juego.getGenero());
        etPlataforma.setText(juego.getPlataforma());
        etAnio.setText(String.valueOf(juego.getAnio()));
        etDesarrollador.setText(juego.getDesarrollador());

        if (juego.getEstado().equals("Jugando")) {

            rgEstado.check(R.id.rbEditarJugando);

        } else if (juego.getEstado().equals("Completado")) {

            rgEstado.check(R.id.rbEditarCompletado);

        } else {

            rgEstado.check(R.id.rbEditarPendiente);
        }
    }

    private void guardarCambios() {

        if (RepositorioJuegos.listaJuegos.isEmpty()) {

            Toast.makeText(
                    this,
                    "No hay videojuegos para editar",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String nombre = etNombre.getText().toString().trim();
        String genero = etGenero.getText().toString().trim();
        String plataforma = etPlataforma.getText().toString().trim();
        String anioTexto = etAnio.getText().toString().trim();
        String desarrollador = etDesarrollador.getText().toString().trim();

        if (nombre.isEmpty() ||
                genero.isEmpty() ||
                plataforma.isEmpty() ||
                anioTexto.isEmpty() ||
                desarrollador.isEmpty()) {

            Toast.makeText(
                    this,
                    "Complete todos los campos",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        int anio = Integer.parseInt(anioTexto);

        String estado;

        int radioSeleccionado = rgEstado.getCheckedRadioButtonId();

        if (radioSeleccionado == R.id.rbEditarJugando) {

            estado = "Jugando";

        } else if (radioSeleccionado == R.id.rbEditarCompletado) {

            estado = "Completado";

        } else {

            estado = "Pendiente";
        }

        int posicion = spinnerJuegos.getSelectedItemPosition();

        Juego juego = RepositorioJuegos.listaJuegos.get(posicion);

        juego.setNombre(nombre);
        juego.setGenero(genero);
        juego.setPlataforma(plataforma);
        juego.setAnio(anio);
        juego.setDesarrollador(desarrollador);
        juego.setEstado(estado);

        Toast.makeText(
                this,
                "Videojuego actualizado correctamente",
                Toast.LENGTH_SHORT
        ).show();

        finish();
    }
}