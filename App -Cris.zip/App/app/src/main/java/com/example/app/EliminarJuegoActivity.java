package com.example.app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EliminarJuegoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.eliminar_juego_activity);

        EditText etNombreEliminar = findViewById(R.id.etNombreEliminar);
        Button btnEliminar = findViewById(R.id.btnEliminarJuego);

        btnEliminar.setOnClickListener(v -> {

            String nombre = etNombreEliminar
                    .getText()
                    .toString()
                    .trim();

            if (nombre.isEmpty()) {

                Toast.makeText(
                        this,
                        "Ingrese el nombre del videojuego",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean eliminado = false;

            for (int i = 0;
                 i < RepositorioJuegos.listaJuegos.size();
                 i++) {

                Juego juego = RepositorioJuegos.listaJuegos.get(i);

                if (juego.getNombre().equalsIgnoreCase(nombre)) {

                    RepositorioJuegos.listaJuegos.remove(i);

                    eliminado = true;

                    break;
                }
            }

            if (eliminado) {

                Toast.makeText(
                        this,
                        "Videojuego eliminado correctamente",
                        Toast.LENGTH_LONG
                ).show();

                finish();

            } else {

                Toast.makeText(
                        this,
                        "No se encontró ese videojuego",
                        Toast.LENGTH_LONG
                ).show();
            }
        });
    }
}