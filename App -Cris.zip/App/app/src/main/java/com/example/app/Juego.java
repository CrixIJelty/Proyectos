package com.example.app;

public class Juego {

    private String nombre;
    private String genero;
    private String plataforma;
    private int anio;
    private String desarrollador;
    private String estado;

    public Juego(String nombre,
                 String genero,
                 String plataforma,
                 int anio,
                 String desarrollador,
                 String estado) {

        this.nombre = nombre;
        this.genero = genero;
        this.plataforma = plataforma;
        this.anio = anio;
        this.desarrollador = desarrollador;
        this.estado = estado;
    }

    public String getNombre() {
        return nombre;
    }

    public String getGenero() {
        return genero;
    }

    public String getPlataforma() {
        return plataforma;
    }

    public int getAnio() {
        return anio;
    }

    public String getDesarrollador() {
        return desarrollador;
    }

    public String getEstado() {
        return estado;
    }

    // Setters para modificar el videojuego

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public void setDesarrollador(String desarrollador) {
        this.desarrollador = desarrollador;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}