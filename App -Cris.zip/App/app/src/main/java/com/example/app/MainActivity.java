package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btnVer, btnAgregar, btnEditar, btnEliminar, btnAcerca, btnSalir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Button btnAgregar = findViewById(R.id.btnAgregar);
        Button btnVer = findViewById(R.id.btnVer);
        Button btnEditar = findViewById(R.id.btnEditar);
        Button btnEliminar = findViewById(R.id.btnEliminar);
        Button btnAcerca = findViewById(R.id.btnAcerca);
        Button btnSalir = findViewById(R.id.btnSalir);
        btnAgregar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AgregarJuegoActivity.class);
            startActivity(intent);
        });

        btnVer.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, VerJuegosActivity.class);
            startActivity(intent);
        });

        btnEditar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditarJuegoActivity.class);
            startActivity(intent);
        });

        btnEliminar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EliminarJuegoActivity.class);
            startActivity(intent);
        });

        btnAcerca.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AcercaActivity.class);
            startActivity(intent);
        });

        btnSalir.setOnClickListener(v -> finish());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnVer = findViewById(R.id.btnVer);
        btnAgregar = findViewById(R.id.btnAgregar);
        btnEditar = findViewById(R.id.btnEditar);
        btnEliminar = findViewById(R.id.btnEliminar);
        btnAcerca = findViewById(R.id.btnAcerca);
        btnSalir = findViewById(R.id.btnSalir);

        btnAgregar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AgregarJuegoActivity.class);
            startActivity(intent);
        });

    }
}