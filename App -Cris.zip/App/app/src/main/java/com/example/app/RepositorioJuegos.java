package com.example.app;

import java.util.ArrayList;

public class RepositorioJuegos {

    // Lista donde se almacenarán todos los videojuegos
    public static ArrayList<Juego> listaJuegos = new ArrayList<>();

}