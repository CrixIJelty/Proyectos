package com.example.app;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.content.Intent;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class VerJuegosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ver_juegos);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top,
                    systemBars.right, systemBars.bottom);
            return insets;
        });

        ListView lvJuegos = findViewById(R.id.lvJuegos);

        ArrayList<String> listaMostrar = new ArrayList<>();

        for (Juego juego : RepositorioJuegos.listaJuegos) {

            listaMostrar.add(
                    juego.getNombre() +
                            "\nGénero: " + juego.getGenero() +
                            "\nPlataforma: " + juego.getPlataforma() +
                            "\nEstado: " + juego.getEstado()
            );
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                listaMostrar
        );

        lvJuegos.setAdapter(adapter);

        lvJuegos.setOnItemClickListener((parent, view, position, id) -> {

            Juego juegoSeleccionado = RepositorioJuegos.listaJuegos.get(position);

            Intent intent = new Intent(VerJuegosActivity.this, DetalleJuegoActivity.class);

            intent.putExtra("nombre", juegoSeleccionado.getNombre());
            intent.putExtra("genero", juegoSeleccionado.getGenero());
            intent.putExtra("plataforma", juegoSeleccionado.getPlataforma());
            intent.putExtra("anio", juegoSeleccionado.getAnio());
            intent.putExtra("desarrollador", juegoSeleccionado.getDesarrollador());
            intent.putExtra("estado", juegoSeleccionado.getEstado());
            intent.putExtra("posicion", position);

            startActivity(intent);
        });
    }
}