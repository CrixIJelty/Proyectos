package com.mycompany.gamevault;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private static final String URL =
            "jdbc:mysql://127.0.0.1:3306/GameVault";

    private static final String USER =
            "root";

    private static final String PASSWORD =
            "Cisco1234";

    public static Connection conectar() {

        try {

            Connection conexion = DriverManager.getConnection(
                    URL,
                    USER,
                    PASSWORD
            );

            System.out.println("Conexión exitosa a GameVault");

            return conexion;

        } catch (SQLException e) {

            System.out.println("Error de conexión:");
            System.out.println(e.getMessage());

            return null;
        }
    }
}