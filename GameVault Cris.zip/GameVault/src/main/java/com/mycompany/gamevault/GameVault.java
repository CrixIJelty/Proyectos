/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gamevault;

/**
 *
 * @author CrixIJelty
 */
public class GameVault {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
