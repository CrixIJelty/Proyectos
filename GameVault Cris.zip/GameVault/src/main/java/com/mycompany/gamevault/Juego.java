package com.mycompany.gamevault;

public class Juego {

    private int id;
    private String nombre;
    private String genero;
    private String plataforma;
    private int anio;
    private String desarrollador;
    private String estado;

    public Juego() {
    }

    public Juego(String nombre, String genero, String plataforma,
                 int anio, String desarrollador, String estado) {

        this.nombre = nombre;
        this.genero = genero;
        this.plataforma = plataforma;
        this.anio = anio;
        this.desarrollador = desarrollador;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getPlataforma() {
        return plataforma;
    }

    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public String getDesarrollador() {
        return desarrollador;
    }

    public void setDesarrollador(String desarrollador) {
        this.desarrollador = desarrollador;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}