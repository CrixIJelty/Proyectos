package com.mycompany.gamevault;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class JuegoDAO {

    // INSERTAR
    public boolean insertar(Juego juego) {

        String sql = "INSERT INTO Videojuegos "
                + "(nombre, genero, plataforma, anio, desarrollador, estado) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, juego.getNombre());
            ps.setString(2, juego.getGenero());
            ps.setString(3, juego.getPlataforma());
            ps.setInt(4, juego.getAnio());
            ps.setString(5, juego.getDesarrollador());
            ps.setString(6, juego.getEstado());

            ps.executeUpdate();

            return true;

        } catch (SQLException e) {

            System.out.println("Error al insertar videojuego:");
            System.out.println(e.getMessage());

            return false;
        }
    }

    // LISTAR
    public ArrayList<Juego> listar() {

        ArrayList<Juego> lista = new ArrayList<>();

        String sql = "SELECT * FROM Videojuegos";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Juego juego = new Juego();

                juego.setId(rs.getInt("id"));
                juego.setNombre(rs.getString("nombre"));
                juego.setGenero(rs.getString("genero"));
                juego.setPlataforma(rs.getString("plataforma"));
                juego.setAnio(rs.getInt("anio"));
                juego.setDesarrollador(rs.getString("desarrollador"));
                juego.setEstado(rs.getString("estado"));

                lista.add(juego);
            }

        } catch (SQLException e) {

            System.out.println("Error al listar videojuegos:");
            System.out.println(e.getMessage());
        }

        return lista;
    }
   
    // ACTUALIZAR
    public boolean actualizar(Juego juego) {

        String sql = "UPDATE Videojuegos SET "
                + "nombre = ?, "
                + "genero = ?, "
                + "plataforma = ?, "
                + "anio = ?, "
                + "desarrollador = ?, "
                + "estado = ? "
                + "WHERE id = ?";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, juego.getNombre());
            ps.setString(2, juego.getGenero());
            ps.setString(3, juego.getPlataforma());
            ps.setInt(4, juego.getAnio());
            ps.setString(5, juego.getDesarrollador());
            ps.setString(6, juego.getEstado());
            ps.setInt(7, juego.getId());

            ps.executeUpdate();

            return true;

        } catch (SQLException e) {

            System.out.println("Error al actualizar videojuego:");
            System.out.println(e.getMessage());

            return false;
        }
        // ELIMINAR
}
    // ELIMINAR
public boolean eliminar(int id) {

    String sql = "DELETE FROM Videojuegos WHERE id = ?";

    try (Connection conexion = Conexion.conectar();
         PreparedStatement ps = conexion.prepareStatement(sql)) {

        ps.setInt(1, id);

        ps.executeUpdate();

        return true;

    } catch (SQLException e) {

        System.out.println("Error al eliminar videojuego:");
        System.out.println(e.getMessage());

        return false;
    }
    }
    public int contarPorEstado(String estado) {

    String sql = "SELECT COUNT(*) FROM Videojuegos WHERE estado = ?";

    try (Connection conexion = Conexion.conectar();
         PreparedStatement ps = conexion.prepareStatement(sql)) {

        ps.setString(1, estado);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return rs.getInt(1);
        }

    } catch (SQLException e) {

        System.out.println("Error al contar videojuegos:");
        System.out.println(e.getMessage());
    }

    return 0;
}
    public int contarTotal() {

    String sql = "SELECT COUNT(*) FROM Videojuegos";

    try (Connection conexion = Conexion.conectar();
         PreparedStatement ps = conexion.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        if (rs.next()) {
            return rs.getInt(1);
        }

    } catch (SQLException e) {

        System.out.println("Error al contar videojuegos:");
        System.out.println(e.getMessage());
    }

    return 0;
}
}