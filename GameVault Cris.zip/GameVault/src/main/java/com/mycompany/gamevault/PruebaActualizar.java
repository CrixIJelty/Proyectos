package com.mycompany.gamevault;

public class PruebaActualizar {

    public static void main(String[] args) {

        Juego juego = new Juego(
                "Minecraft",
                "Sandbox",
                "PC",
                2011,
                "Mojang",
                "Completado"
        );

        juego.setId(2);

        JuegoDAO dao = new JuegoDAO();

        boolean resultado = dao.actualizar(juego);

        if (resultado) {
            System.out.println("Videojuego actualizado correctamente.");
        } else {
            System.out.println("No se pudo actualizar el videojuego.");
        }
    }
}