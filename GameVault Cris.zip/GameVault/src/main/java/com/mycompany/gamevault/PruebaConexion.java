package com.mycompany.gamevault;

import java.sql.Connection;

public class PruebaConexion {

    public static void main(String[] args) {

        Connection conexion = Conexion.conectar();

        if (conexion != null) {

            System.out.println("¡Conexion funcionando correctamente!");

            try {
                conexion.close();
            } catch (Exception e) {
                System.out.println("Error al cerrar la conexión.");
            }

        } else {

            System.out.println("No se pudo conectar a MySQL.");
        }
    }
}