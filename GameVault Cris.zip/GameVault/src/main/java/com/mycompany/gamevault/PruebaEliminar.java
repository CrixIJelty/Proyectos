package com.mycompany.gamevault;

public class PruebaEliminar {

    public static void main(String[] args) {

        JuegoDAO dao = new JuegoDAO();

        int id = 2;

        boolean resultado = dao.eliminar(id);

        if (resultado) {
            System.out.println("Videojuego eliminado correctamente.");
        } else {
            System.out.println("No se pudo eliminar el videojuego.");
        }
    }
}