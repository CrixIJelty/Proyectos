package com.mycompany.gamevault;

public class PruebaInsertar {

    public static void main(String[] args) {

        Juego juego = new Juego(
                "Minecraft",
                "Sandbox",
                "PC",
                2011,
                "Mojang",
                "Jugando"
        );

        JuegoDAO dao = new JuegoDAO();

        boolean resultado = dao.insertar(juego);

        if (resultado) {
            System.out.println("Videojuego insertado correctamente.");
        } else {
            System.out.println("No se pudo insertar el videojuego.");
        }
    }
}