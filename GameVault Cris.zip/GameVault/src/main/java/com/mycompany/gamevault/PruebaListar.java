package com.mycompany.gamevault;

import java.util.ArrayList;

public class PruebaListar {

    public static void main(String[] args) {

        JuegoDAO dao = new JuegoDAO();

        ArrayList<Juego> lista = dao.listar();

        System.out.println("Videojuegos registrados:");

        for (Juego juego : lista) {

            System.out.println("-------------------------");
            System.out.println("ID: " + juego.getId());
            System.out.println("Nombre: " + juego.getNombre());
            System.out.println("Género: " + juego.getGenero());
            System.out.println("Plataforma: " + juego.getPlataforma());
            System.out.println("Año: " + juego.getAnio());
            System.out.println("Desarrollador: " + juego.getDesarrollador());
            System.out.println("Estado: " + juego.getEstado());
        }
    }
}